package com.os.kotlin_sayfalar_arasi_gecis


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val gonderButton = findViewById<Button>(R.id.button)
        gonderButton.setOnClickListener {
            degistir()
        }
        val gonder2Button = findViewById<Button>(R.id.button3)
        gonder2Button.setOnClickListener {
            dialogGoster()
        }


    }

    //2. sayfaya veri gönder
    fun degistir() {
        val intent=Intent(applicationContext,ikincisayfa::class.java)

        val metin=findViewById<EditText>(R.id.editText)
        val text=metin.text.toString()

        intent.putExtra("gonderilen",text)

        startActivity(intent)
    }

    fun dialogGoster() {
        val mesaj = AlertDialog.Builder(this)
        mesaj.setTitle("Uyarı Dialog Kutusu")
        mesaj.setMessage("Uyarı Mesajları Burada")
        mesaj.setPositiveButton("Evet") { dialogInterface, i ->
            Toast.makeText(this, "Evet'i seçtiniz", Toast.LENGTH_LONG).show()
        }
        mesaj.setNegativeButton("Hayır") { dialogInterface, i ->
            Toast.makeText(this, "Hayır'ı seçtiniz", Toast.LENGTH_LONG).show()
        }

        // Dialog'u göster
        val dialog = mesaj.create()
        dialog.show()
    }

}